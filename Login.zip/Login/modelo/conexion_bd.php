<?php 
$conexion=new mysqli("localhost","root","","login","3306");
$conexion->set_charset("utf8")
?>