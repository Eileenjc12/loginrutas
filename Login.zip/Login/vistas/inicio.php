
<?php 
  include("../layouts/header.php");
?>

    <main class="content">
        <section class="welcome-card">
            <h1>¡Bienvenido de nuevo!</h1>
            <p>Has iniciado sesión correctamente. Este es tu panel principal.</p>
            <div class="stats">
                <div class="stat-box">
                    <h3>Tareas</h3>
                    <p>5 pendientes</p>
                </div>
                <div class="stat-box">
                    <h3>Mensajes</h3>
                    <p>2 nuevos</p>
                </div>
            </div>
        </section>
    </main>

<?php 
  include('registrousers.php');
?>
<!--
<iframe src="https://youdj.online" width="800" height="600" frameborder="0"></iframe>
-->

