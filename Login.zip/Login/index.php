<?php
// 1. Incluimos la conexión (Modelo)
include "modelo/conexion_bd.php";

// 2. Incluimos la lógica del login (Controlador)
include "controlador/control_login.php";
include "controlador/control_registrousar.php";
?>
<?php 
    include('layouts/header.php');
?>


<?php 
    include('vistas/login.php');
?>


<?php 
    include('layouts/footer.php');
?>
